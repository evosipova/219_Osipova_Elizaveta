﻿using System;
using StackExchange.Redis;

namespace TaskListSolution
{
    public static class RedisClient
    {
       
    }
}